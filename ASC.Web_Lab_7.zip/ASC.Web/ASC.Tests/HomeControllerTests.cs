﻿using ASC.Web.Configurations;
using ASC.Web.Controllers;
using ASC.Web.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using Moq;
using Xunit;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

public class HomeControllerTests
{
    private readonly Mock<IOptions<ApplicationSettings>> optionsMock;

    public HomeControllerTests()
    {
        // Tạo mock IOptions
        optionsMock = new Mock<IOptions<ApplicationSettings>>();

        // Setup dữ liệu giả
        optionsMock.Setup(x => x.Value).Returns(new ApplicationSettings
        {
            ApplicationTitle = "ASC"
        });
    }

    [Fact]
    public void HomeController_Index_View_Test()
    {
        var controller = new HomeController(optionsMock.Object);

        // 👉 TẠO HttpContext giả
        var httpContext = new DefaultHttpContext();
        httpContext.Session = new FakeSession();

        controller.ControllerContext = new ControllerContext()
        {
            HttpContext = httpContext
        };

        var result = controller.Index();

        Assert.IsType<ViewResult>(result);
    }
    [Fact]
    public void HomeController_Index_NoModel_Test()
    {
        var controller = new HomeController(optionsMock.Object);

        var httpContext = new DefaultHttpContext();
        httpContext.Session = new FakeSession();

        controller.ControllerContext = new ControllerContext()
        {
            HttpContext = httpContext
        };

        var result = controller.Index() as ViewResult;

        Assert.Null(result.ViewData.Model);
    }
    [Fact]
    public void HomeController_Index_Validation_Test()
    {
        var controller = new HomeController(optionsMock.Object);

        var httpContext = new DefaultHttpContext();
        httpContext.Session = new FakeSession();

        controller.ControllerContext = new ControllerContext()
        {
            HttpContext = httpContext
        };

        var result = controller.Index() as ViewResult;

        Assert.True(controller.ModelState.IsValid);
    }
}