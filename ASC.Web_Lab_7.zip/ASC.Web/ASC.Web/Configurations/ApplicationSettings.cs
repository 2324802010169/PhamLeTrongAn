﻿namespace ASC.Web.Configurations
{
    public class ApplicationSettings
    {
        public string ApplicationTitle { get; set; }
    }
}
