using ASC.Web.Configuration;
using ASC.Web.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;

namespace ASC.Web.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly ApplicationSettings _settings;
        private readonly IEmailSender _emailSender;

        public HomeController(
            ILogger<HomeController> logger,
            IOptions<ApplicationSettings> settings,
            IEmailSender emailSender)
        {
            _logger = logger;
            _settings = settings.Value;
            _emailSender = emailSender;
        }

        public IActionResult Index()
        {
            ViewBag.ApplicationName = _settings.ApplicationName;
            return View();
        }

        public IActionResult Dashboard()
        {
            return View();
        }
    }
}